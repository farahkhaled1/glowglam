<?php
	include '../includes/conn.php';
	session_start();

	if(!isset($_SESSION['auditor']) || trim($_SESSION['auditor']) == ''){
		header('location: ../index.php');
		exit();
	}

	$conn = $pdo->open();

	$stmt = $conn->prepare("SELECT * FROM users WHERE id=:id");
	$stmt->execute(['id'=>$_SESSION['auditor']]);
	$auditor = $stmt->fetch();

	$pdo->close();

?>